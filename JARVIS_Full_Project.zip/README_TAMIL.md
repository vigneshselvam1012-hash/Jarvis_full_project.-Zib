# JARVIS Android Project

## Android Studio-ல் திறப்பது
1. ZIP-ஐ extract செய்யவும்.
2. Android Studio → Open → extract செய்த `JARVIS_Full_Project` folder தேர்வு செய்யவும்.
3. Gradle Sync முடியும் வரை காத்திருக்கவும்.
4. Android SDK Platform 35 மற்றும் JDK 17 நிறுவப்பட்டிருக்க வேண்டும்.
5. மொபைலை USB debugging மூலம் இணைத்து Run செய்யவும் அல்லது Build → Build APK(s) தேர்வு செய்யவும்.

## Gemini API Key அமைப்பது
1. Google AI Studio-வில் Gemini API key உருவாக்கவும்.
2. App திறந்து Settings செல்லவும்.
3. API key மற்றும் model name (`gemini-2.0-flash`) உள்ளிட்டு Save செய்யவும்.
4. இணைய இணைப்பு தேவை.

## இதில் உள்ள அம்சங்கள்
- Gemini chat (API key தேவை)
- தமிழ்/ஆங்கில text-to-speech
- Flashlight toggle
- Notes சேமித்தல் மற்றும் பார்க்குதல் (Room database)
- Alarm screen திறத்தல்
- Phone dialer திறத்தல்
- Voice output rate/pitch settings

## முக்கிய வரம்புகள்
- இந்த source project இங்கு Android SDK/Gradle build environment இல்லாததால் APK ஆக compile செய்து சோதிக்கப்படவில்லை.
- Gemini API key-ஐ app preferences-ல் சேமிக்கிறது; இது production-grade secret storage அல்ல. பொது விநியோகத்திற்கு backend proxy மற்றும் பாதுகாப்பான key management பயன்படுத்தவும்.
- Speech recognition / wake word இன்னும் சேர்க்கப்படவில்லை.
- Alarm செயல்பாடு system Clock app-ன் alarm screen-ஐத் திறக்கும்.
- Phone action default-ஆக dialer-ஐத் திறக்கும்; direct call permission கோரப்படவில்லை.

## Troubleshooting
- Gradle sync failure: Android Studio-வில் Gradle JDK 17 தேர்வு செய்யவும்.
- API error: API key, model availability, internet permission மற்றும் network connection சரிபார்க்கவும்.
