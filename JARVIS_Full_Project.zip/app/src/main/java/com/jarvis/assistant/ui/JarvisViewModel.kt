package com.jarvis.assistant.ui

import android.app.Application
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.data.local.JarvisDatabase
import com.jarvis.assistant.data.local.JarvisSettings
import com.jarvis.assistant.data.local.SettingsManager
import com.jarvis.assistant.data.remote.GeminiRepository
import com.jarvis.assistant.domain.DeviceActionExecutor
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Locale

data class ChatMessage(val text: String, val fromUser: Boolean)

class JarvisViewModel(app: Application) : AndroidViewModel(app) {
    private val settingsManager = SettingsManager(app)
    private val repository = GeminiRepository()
    private val dao = JarvisDatabase.getInstance(app).dao()
    private val actions = DeviceActionExecutor(app, dao)

    val settings: StateFlow<JarvisSettings> = settingsManager.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), JarvisSettings())
    private val _messages = MutableStateFlow(
        listOf(ChatMessage("வணக்கம்! நான் JARVIS. என்ன உதவி வேண்டும்?", false))
    )
    val messages = _messages.asStateFlow()
    private val _loading = MutableStateFlow(false)
    val loading = _loading.asStateFlow()
    private val _status = MutableStateFlow("")
    val status = _status.asStateFlow()

    fun send(text: String) {
        val prompt = text.trim()
        if (prompt.isEmpty() || _loading.value) return
        _messages.update { it + ChatMessage(prompt, true) }
        viewModelScope.launch {
            _loading.value = true
            val s = settings.value
            val response = repository.ask(
                s.apiKey, s.modelName,
                "You are JARVIS, a helpful assistant. Reply in the language used by the user. User message: $prompt"
            )
            _messages.update { it + ChatMessage(response, false) }
            if (s.voiceOutputEnabled) speak(response, s)
            _loading.value = false
        }
    }

    private var tts: TextToSpeech? = null
    private fun speak(text: String, s: JarvisSettings) {
        if (tts == null) {
            tts = TextToSpeech(getApplication()) { result ->
                if (result == TextToSpeech.SUCCESS) {
                    val locale = if (s.preferredLanguage.startsWith("ta")) Locale("ta", "IN") else Locale("en", "IN")
                    tts?.language = locale
                    tts?.setSpeechRate(s.speechRate)
                    tts?.setPitch(s.speechPitch)
                    tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
                }
            }
        } else {
            tts?.setSpeechRate(s.speechRate)
            tts?.setPitch(s.speechPitch)
            tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
        }
    }

    fun stopSpeaking() { tts?.stop() }
    fun flashlight(on: Boolean) { _status.value = actions.toggleFlashlight(on) }
    fun alarm(hour: Int, minute: Int) { _status.value = actions.setAlarm(hour, minute) }
    fun dial(number: String) { _status.value = actions.dial(number) }
    fun saveNote(note: String) { viewModelScope.launch { _status.value = actions.saveNote(note) } }
    fun loadNotes() { viewModelScope.launch { _status.value = actions.notes() } }
    fun setApiKey(v: String) { viewModelScope.launch { settingsManager.updateApiKey(v) } }
    fun setModel(v: String) { viewModelScope.launch { settingsManager.updateModel(v) } }
    fun setLanguage(v: String) { viewModelScope.launch { settingsManager.updateLanguage(v) } }
    fun setVoice(v: Boolean) { viewModelScope.launch { settingsManager.updateVoiceOutput(v) } }
    fun setRate(v: Float) { viewModelScope.launch { settingsManager.updateSpeechRate(v) } }
    fun setPitch(v: Float) { viewModelScope.launch { settingsManager.updateSpeechPitch(v) } }

    override fun onCleared() {
        tts?.stop()
        tts?.shutdown()
        super.onCleared()
    }
}
