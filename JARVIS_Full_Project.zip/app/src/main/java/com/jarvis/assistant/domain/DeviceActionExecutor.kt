package com.jarvis.assistant.domain

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import androidx.core.content.ContextCompat
import com.jarvis.assistant.data.local.JarvisDao
import com.jarvis.assistant.data.local.JarvisItemEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DeviceActionExecutor(private val context: Context, private val dao: JarvisDao) {
    private var flashlightOn = false

    suspend fun saveNote(title: String, category: String = "NOTE"): String {
        if (title.isBlank()) return "காலியான குறிப்பைச் சேமிக்க முடியாது."
        val type = if (category.uppercase().contains("REMIND")) "REMINDER" else "NOTE"
        dao.insert(JarvisItemEntity(title = title.trim(), category = type))
        return "$type சேமிக்கப்பட்டது: $title"
    }

    suspend fun notes(): String {
        val items = dao.getActiveItems()
        return if (items.isEmpty()) "சேமித்த குறிப்புகள் இல்லை."
        else items.joinToString("\n") { "- [${it.category}] ${it.title}" }
    }

    fun toggleFlashlight(enable: Boolean): String {
        return try {
            val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (cameraId == null) {
                "இந்த மொபைலில் Flashlight கிடைக்கவில்லை."
            } else {
                manager.setTorchMode(cameraId, enable)
                flashlightOn = enable
                if (enable) "Flashlight ON" else "Flashlight OFF"
            }
        } catch (e: Exception) {
            "Flashlight இயக்க முடியவில்லை: ${e.localizedMessage}"
        }
    }

    fun setAlarm(hour: Int, minute: Int, label: String = "JARVIS Alarm"): String {
        if (hour !in 0..23 || minute !in 0..59) return "சரியான நேரத்தை உள்ளிடவும்."
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return runCatching { context.startActivity(intent); "Alarm அமைக்கும் திரை திறக்கப்பட்டது." }
            .getOrElse { "Alarm திறக்க முடியவில்லை: ${it.localizedMessage}" }
    }

    fun dial(number: String): String {
        val clean = number.filter { it.isDigit() || it == '+' }
        if (clean.isBlank()) return "சரியான phone number உள்ளிடவும்."
        val hasPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val intent = Intent(if (hasPermission) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$clean"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching {
            context.startActivity(intent)
            if (hasPermission) "Call தொடங்கப்பட்டது." else "Dialer திறக்கப்பட்டது; Call செய்ய நீங்களே உறுதிப்படுத்தவும்."
        }.getOrElse { "Dialer திறக்க முடியவில்லை: ${it.localizedMessage}" }
    }

    fun currentDateTime(): String =
        SimpleDateFormat("EEEE, dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
}
