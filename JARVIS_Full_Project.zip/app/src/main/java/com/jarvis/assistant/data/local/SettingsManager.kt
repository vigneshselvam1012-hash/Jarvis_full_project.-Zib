package com.jarvis.assistant.data.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "jarvis_settings")

data class JarvisSettings(
    val apiKey: String = "",
    val modelName: String = "gemini-2.0-flash",
    val preferredLanguage: String = "ta-IN",
    val voiceOutputEnabled: Boolean = true,
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f
)

class SettingsManager(private val context: Context) {
    private object Keys {
        val API_KEY = stringPreferencesKey("api_key")
        val MODEL_NAME = stringPreferencesKey("model_name")
        val LANGUAGE = stringPreferencesKey("language")
        val VOICE_OUTPUT = booleanPreferencesKey("voice_output")
        val SPEECH_RATE = floatPreferencesKey("speech_rate")
        val SPEECH_PITCH = floatPreferencesKey("speech_pitch")
    }
    val settingsFlow: Flow<JarvisSettings> = context.dataStore.data.map { p ->
        JarvisSettings(
            apiKey = p[Keys.API_KEY] ?: "",
            modelName = p[Keys.MODEL_NAME] ?: "gemini-2.0-flash",
            preferredLanguage = p[Keys.LANGUAGE] ?: "ta-IN",
            voiceOutputEnabled = p[Keys.VOICE_OUTPUT] ?: true,
            speechRate = p[Keys.SPEECH_RATE] ?: 1.0f,
            speechPitch = p[Keys.SPEECH_PITCH] ?: 1.0f
        )
    }
    suspend fun updateApiKey(v: String) { context.dataStore.edit { it[Keys.API_KEY] = v.trim() } }
    suspend fun updateModel(v: String) { context.dataStore.edit { it[Keys.MODEL_NAME] = v.trim() } }
    suspend fun updateLanguage(v: String) { context.dataStore.edit { it[Keys.LANGUAGE] = v } }
    suspend fun updateVoiceOutput(v: Boolean) { context.dataStore.edit { it[Keys.VOICE_OUTPUT] = v } }
    suspend fun updateSpeechRate(v: Float) { context.dataStore.edit { it[Keys.SPEECH_RATE] = v.coerceIn(0.5f, 2f) } }
    suspend fun updateSpeechPitch(v: Float) { context.dataStore.edit { it[Keys.SPEECH_PITCH] = v.coerceIn(0.5f, 2f) } }
}
