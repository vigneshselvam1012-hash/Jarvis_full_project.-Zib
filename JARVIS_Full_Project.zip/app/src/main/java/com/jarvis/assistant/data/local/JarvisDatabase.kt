package com.jarvis.assistant.data.local

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "notes_reminders")
data class JarvisItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isCompleted: Boolean = false
)

@Dao
interface JarvisDao {
    @Query("SELECT * FROM notes_reminders ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<JarvisItemEntity>>
    @Query("SELECT * FROM notes_reminders WHERE isCompleted = 0 ORDER BY timestamp DESC")
    suspend fun getActiveItems(): List<JarvisItemEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: JarvisItemEntity): Long
    @Query("DELETE FROM notes_reminders WHERE id = :id")
    suspend fun deleteById(id: Int)
}

@Database(entities = [JarvisItemEntity::class], version = 1, exportSchema = false)
abstract class JarvisDatabase : RoomDatabase() {
    abstract fun dao(): JarvisDao
    companion object {
        @Volatile private var INSTANCE: JarvisDatabase? = null
        fun getInstance(context: Context): JarvisDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext, JarvisDatabase::class.java, "jarvis_core.db"
                ).build().also { INSTANCE = it }
            }
    }
}
