package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ui.JarvisViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: JarvisViewModel, onBack: () -> Unit) {
    val settings by viewModel.settings.collectAsState()
    var apiKey by remember(settings.apiKey) { mutableStateOf(settings.apiKey) }
    var model by remember(settings.modelName) { mutableStateOf(settings.modelName) }
    var language by remember(settings.preferredLanguage) { mutableStateOf(settings.preferredLanguage) }
    Scaffold(topBar = {
        TopAppBar(title = { Text("JARVIS Settings") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
        })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Gemini API", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(apiKey, { apiKey = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("Gemini API key") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            OutlinedTextField(model, { model = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Model name") }, singleLine = true)
            Button(onClick = { viewModel.setApiKey(apiKey); viewModel.setModel(model) }, modifier = Modifier.fillMaxWidth()) {
                Text("Save API settings")
            }
            HorizontalDivider()
            Text("Voice settings", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Voice output")
                Switch(checked = settings.voiceOutputEnabled, onCheckedChange = viewModel::setVoice)
            }
            Text("Language")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = language == "ta-IN", onClick = { language = "ta-IN"; viewModel.setLanguage(language) }, label = { Text("தமிழ்") })
                FilterChip(selected = language == "en-IN", onClick = { language = "en-IN"; viewModel.setLanguage(language) }, label = { Text("English") })
            }
            Text("Speech rate: ${"%.2f".format(settings.speechRate)}")
            Slider(value = settings.speechRate, onValueChange = viewModel::setRate, valueRange = 0.5f..2f)
            Text("Speech pitch: ${"%.2f".format(settings.speechPitch)}")
            Slider(value = settings.speechPitch, onValueChange = viewModel::setPitch, valueRange = 0.5f..2f)
            Text("API key is stored in app preferences. Do not share it with anyone.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
