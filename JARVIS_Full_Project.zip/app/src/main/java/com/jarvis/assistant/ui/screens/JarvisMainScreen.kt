package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.assistant.ui.JarvisViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisMainScreen(viewModel: JarvisViewModel, onOpenSettings: () -> Unit) {
    val messages by viewModel.messages.collectAsState()
    val loading by viewModel.loading.collectAsState()
    val status by viewModel.status.collectAsState()
    var input by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var alarmHour by remember { mutableStateOf("7") }
    var alarmMinute by remember { mutableStateOf("00") }
    var flashOn by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Column { Text("JARVIS", color = Color(0xFF7DE3FF)); Text("Personal AI Assistant", fontSize = 11.sp) } },
                actions = { IconButton(onClick = onOpenSettings) { Icon(Icons.Default.Settings, "Settings") } }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().background(Color(0xFF0B1220)).padding(padding).padding(12.dp)
        ) {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(messages) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(
                            color = if (msg.fromUser) Color(0xFF164E63) else Color(0xFF1E293B),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) { Text(msg.text, Modifier.padding(12.dp), color = Color.White) }
                    }
                }
                if (loading) item { Text("JARVIS is thinking...", color = Color(0xFF7DE3FF)) }
            }
            if (status.isNotBlank()) {
                Text(status, color = Color(0xFFB6E3A8), modifier = Modifier.padding(vertical = 6.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                    placeholder = { Text("Message JARVIS...") }, maxLines = 4
                )
                IconButton(onClick = { viewModel.send(input); input = "" }, enabled = !loading) {
                    Icon(Icons.Default.Send, "Send", tint = Color(0xFF7DE3FF))
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Quick actions", color = Color(0xFF7DE3FF), style = MaterialTheme.typography.titleSmall)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilledTonalButton(onClick = { flashOn = !flashOn; viewModel.flashlight(flashOn) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.FlashlightOn, null); Spacer(Modifier.width(4.dp)); Text("Flash")
                }
                FilledTonalButton(onClick = viewModel::loadNotes, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Notes, null); Spacer(Modifier.width(4.dp)); Text("Notes")
                }
                FilledTonalButton(onClick = viewModel::stopSpeaking, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.VolumeOff, null); Spacer(Modifier.width(4.dp)); Text("Stop voice")
                }
            }
            var showTools by remember { mutableStateOf(false) }
            TextButton(onClick = { showTools = !showTools }) { Text(if (showTools) "Hide tools" else "More device tools") }
            if (showTools) {
                OutlinedTextField(note, { note = it }, label = { Text("Save a note") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { viewModel.saveNote(note); note = "" }, enabled = note.isNotBlank()) { Text("Save note") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(phone, { phone = it }, label = { Text("Phone number") }, modifier = Modifier.weight(1f))
                    Button(onClick = { viewModel.dial(phone) }) { Text("Dial") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(alarmHour, { alarmHour = it.filter(Char::isDigit).take(2) }, label = { Text("Hour") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(alarmMinute, { alarmMinute = it.filter(Char::isDigit).take(2) }, label = { Text("Minute") }, modifier = Modifier.weight(1f))
                    Button(onClick = { viewModel.alarm(alarmHour.toIntOrNull() ?: -1, alarmMinute.toIntOrNull() ?: -1) }) { Text("Alarm") }
                }
            }
        }
    }
}
