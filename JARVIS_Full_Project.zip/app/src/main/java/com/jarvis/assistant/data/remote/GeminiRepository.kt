package com.jarvis.assistant.data.remote

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GeminiRepository {
    private val client = OkHttpClient.Builder()
        .callTimeout(45, TimeUnit.SECONDS)
        .build()

    suspend fun ask(apiKey: String, model: String, prompt: String): String = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext "முதலில் Settings-ல் Gemini API key சேர்க்கவும்."
        val safeModel = model.ifBlank { "gemini-2.0-flash" }
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$safeModel:generateContent?key=$apiKey"
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        val body = JSONObject().put(
            "contents", JSONArray().put(JSONObject().put("parts", parts))
        ).put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 2048))
        val request = Request.Builder()
            .url(url)
            .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        return try {
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val message = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
                    "API error (${response.code}): ${message ?: "Request failed. Check API key and model name."}"
                } else {
                    val candidate = JSONObject(raw).optJSONArray("candidates")
                        ?.optJSONObject(0)?.optJSONObject("content")
                        ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
                    candidate?.takeIf { it.isNotBlank() } ?: "JARVIS-க்கு பதில் கிடைக்கவில்லை. மீண்டும் முயற்சிக்கவும்."
                }
            }
        } catch (e: IOException) {
            "Internet connection பிரச்சினை: ${e.localizedMessage ?: "Network unavailable"}"
        } catch (e: Exception) {
            "பிழை: ${e.localizedMessage ?: "Unknown error"}"
        }
    }
}
