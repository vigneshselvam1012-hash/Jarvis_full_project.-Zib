package com.jarvis.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.assistant.ui.JarvisViewModel
import com.jarvis.assistant.ui.screens.JarvisMainScreen
import com.jarvis.assistant.ui.screens.SettingsScreen
import com.jarvis.assistant.ui.theme.JarvisTheme
import androidx.compose.runtime.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JarvisTheme {
                val vm: JarvisViewModel = viewModel()
                var settingsOpen by remember { mutableStateOf(false) }
                if (settingsOpen) SettingsScreen(vm, onBack = { settingsOpen = false })
                else JarvisMainScreen(vm, onOpenSettings = { settingsOpen = true })
            }
        }
    }
}
